# iot-makeathon-website

Website for VIT Chennai's IoT Makeathon v5.0. Static version [here](https://abithakt.github.io/iot-makeathon-website/).
